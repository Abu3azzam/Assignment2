%%question 1 a)
n=5;
L=1;
delta=(L/n);
D0=-2*diag(ones(n,1));
D1=diag(ones(n-1,1),1);
D2=diag(ones(n-1,1),-1);
D=D0+D1+D2;
V=zeros(1,n+1);
V0=1;
F=zeros(1,n);
V(1)=V0;
V(end)=0;
F(1)=-V0;
F(end)=0;
Q=inv(D)*F';
for i=1:n-1
    V(i+1)=Q(i);
end
N=0:n;
x=delta*N;
figure(1)
plot(x,V)
xlabel('x')
ylabel('V')

%%question 1 b)
A=[-4 1 1 0;2 -4 0 1;2 0 -4 1;0 2 2 -4];
B=[-V0 0 -V0 -V0]';
vv=inv(A)*B;
VV=zeros(5,5);
VV(1,:)=0;
VV(end,:)=0;
VV(:,1)=V0;
VV(:,end)=V0;
VV(2,2)=vv(1);
VV(2,4)=vv(1);
VV(4,2)=vv(1);
VV(4,4)=vv(1);
VV(2,3)=vv(2);
VV(4,3)=vv(2);
VV(3,2)=vv(3);
VV(3,4)=vv(3);
VV(3,3)=vv(4);
figure(2)
x = 0:0.25:1;
y = 0:0.35:1.5;
[X,Y] = meshgrid(x,y);
surf(X,Y,VV)
%%%exact solution
syms f(x,y)
n=1:2:100;
f(x,y) = (4*V0/pi)*(sum((1./n).*((cosh(n*pi*x/1.5))./(cosh(n*pi/1.5))).*sin(n*pi*y/1.5)));
i=1;
V1=zeros(5,5);
for xeval=0:0.25:1
yeval=0:0.35:1.5;
V1(:,i)=vpa(f(xeval,yeval));
i=i+1;
end
V1=vpa(V1,2)